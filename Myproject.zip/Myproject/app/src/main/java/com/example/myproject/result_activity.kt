package com.example.myproject

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.CheckBox
import android.widget.RadioButton
import android.widget.Toast

class ResultActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result)
        val m : RadioButton = findViewById<RadioButton>(R.id.male)
        val f : RadioButton = findViewById<RadioButton>(R.id.female)

        val r : CheckBox = findViewById<CheckBox>(R.id.rem)
        m.setOnClickListener{

            Toast.makeText(applicationContext, "Male", Toast.LENGTH_SHORT).show()
        }

        f.setOnClickListener{
            Toast.makeText(applicationContext, "Female", Toast.LENGTH_SHORT).show()
        }

        r.setOnClickListener{
            Toast.makeText(applicationContext, "Remember me", Toast.LENGTH_SHORT).show()
        }
    }
}